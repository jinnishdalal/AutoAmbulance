<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class admin_payment_settings extends Model
{
    //
}
