<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Productunits extends Model
{
    protected $fillable = [
        'name', 'created_by'
    ];


    protected $hidden = [

    ];
}
